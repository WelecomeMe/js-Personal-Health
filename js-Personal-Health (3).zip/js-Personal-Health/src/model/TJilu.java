package model;

public class TJilu
{
	private int id;
	private int yonghu_id;
	private String shijian;
	private String yinshi;
	
	private String yundong;
	private String shuimian;
	private String beizhu;
	
	
	
	public String getBeizhu()
	{
		return beizhu;
	}
	public void setBeizhu(String beizhu)
	{
		this.beizhu = beizhu;
	}
	public String getShijian()
	{
		return shijian;
	}
	public void setShijian(String shijian)
	{
		this.shijian = shijian;
	}
	public String getShuimian()
	{
		return shuimian;
	}
	public void setShuimian(String shuimian)
	{
		this.shuimian = shuimian;
	}
	
	public int getId()
	{
		return id;
	}
	public void setId(int id)
	{
		this.id = id;
	}
	public int getYonghu_id()
	{
		return yonghu_id;
	}
	public void setYonghu_id(int yonghu_id)
	{
		this.yonghu_id = yonghu_id;
	}
	public String getYinshi()
	{
		return yinshi;
	}
	public void setYinshi(String yinshi)
	{
		this.yinshi = yinshi;
	}
	public String getYundong()
	{
		return yundong;
	}
	public void setYundong(String yundong)
	{
		this.yundong = yundong;
	}

}
