package model;

public class TTijian
{
	private int id;
	private int yonghu_id;
	private String shijian;
	private String jieguo;
	
	
	
	public int getId()
	{
		return id;
	}
	public void setId(int id)
	{
		this.id = id;
	}
	public String getJieguo()
	{
		return jieguo;
	}
	public void setJieguo(String jieguo)
	{
		this.jieguo = jieguo;
	}
	public String getShijian()
	{
		return shijian;
	}
	public void setShijian(String shijian)
	{
		this.shijian = shijian;
	}
	public int getYonghu_id()
	{
		return yonghu_id;
	}
	public void setYonghu_id(int yonghu_id)
	{
		this.yonghu_id = yonghu_id;
	}
	

}
