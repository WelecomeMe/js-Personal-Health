package model;

public class THuodong
{
	private int id;
	private int yonghu_id;
	private String shijian;
	private String didian;
	
	private String xingshi;
	private String zhuti;
	private String zuzhizhe;
	private String neirong;
	
	
	
	public String getDidian()
	{
		return didian;
	}
	public void setDidian(String didian)
	{
		this.didian = didian;
	}
	public int getId()
	{
		return id;
	}
	public void setId(int id)
	{
		this.id = id;
	}
	public String getNeirong()
	{
		return neirong;
	}
	public void setNeirong(String neirong)
	{
		this.neirong = neirong;
	}
	public String getShijian()
	{
		return shijian;
	}
	public void setShijian(String shijian)
	{
		this.shijian = shijian;
	}
	public String getXingshi()
	{
		return xingshi;
	}
	public void setXingshi(String xingshi)
	{
		this.xingshi = xingshi;
	}
	public int getYonghu_id()
	{
		return yonghu_id;
	}
	public void setYonghu_id(int yonghu_id)
	{
		this.yonghu_id = yonghu_id;
	}
	public String getZhuti()
	{
		return zhuti;
	}
	public void setZhuti(String zhuti)
	{
		this.zhuti = zhuti;
	}
	public String getZuzhizhe()
	{
		return zuzhizhe;
	}
	public void setZuzhizhe(String zuzhizhe)
	{
		this.zuzhizhe = zuzhizhe;
	}

}
